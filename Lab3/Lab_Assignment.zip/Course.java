class Course
{
    private String name;
    private int units;

    public Course(String name, int units)
    {
        this.name = name;
        this.units = units;
    }

    public String getName()
    {
        return this.name;
    }

    public int getUnits()
    {
        return units;
    }
}